package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {
	@FindBy(id = "graduation")
	private WebElement graduation;

	@FindBy(id = "percentage")
	private WebElement percentage;

	@FindBy(id = "passingYear")
	private WebElement passingYear;

	@FindBy(id = "pname")
	private WebElement pname;

	@FindBy(id = "technologies")
	private WebElement technologies;

	@FindBy(id = "otherT")
	private WebElement otherT;

	@FindBy(id = "login")
	private WebElement login;

	public void selectGraduation(int idx) {
		Select select = new Select(graduation);
		select.selectByIndex(idx);
	}

	public String getPercentage() {
		return percentage.getAttribute("value");
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);

	}

	public String getPassingYear() {
		return passingYear.getAttribute("value");
	}

	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}

	public String getProjectName() {
		return pname.getAttribute("value");
	}

	public void setProjectName(String pname) {
		this.pname.sendKeys(pname);

	}

	public void selectTechnologies(int idx) {
		Select select = new Select(technologies);
		select.selectByIndex(idx);
	}

	public void selectOther() {
		this.otherT.click();
	}

	public void clickLogin() {
		login.click();
	}
}
