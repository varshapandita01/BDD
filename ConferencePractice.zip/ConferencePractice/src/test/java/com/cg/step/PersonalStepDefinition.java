package com.cg.step;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;

	@Before
	public void init() throws InterruptedException {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");

	}

	@Given("^User is on 'PersonalDetails' Page$")
	public void user_is_on_PersonalDetails_Page() throws Throwable {
		driver = new ChromeDriver();
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\ConferencePractice\\html\\PersonalDetails.html";
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}

	@Then("^Page Title Matched successfully$")
	public void page_Title_matched_Successfully() throws Throwable {
		String title = driver.getTitle();
		if (title.equals("Personal Details")) {
			System.out.println("correcte Title");
		} else {
			System.out.println("incorect title");
		}
	}

	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
		personal.setFirstname("");
	}

	@Then("^display 'Please fill the valid First Name'$")
	public void display_Please_fill_the_valid_First_Name() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("");
	}

	@Then("^display 'Please fill the valid Last Name'$")
	public void display_Please_fill_the_valid_Last_Name() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha");
	}

	@Then("^display 'Please fill the valid Email'$")
	public void display_Please_fill_the_valid_Email() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid contact$")
	public void user_enters_invalid_contact() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("12");
	}

	@Then("^display 'Please fill the  Contact'$")
	public void display_Please_fill_the_Contact() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("a");

	}

	@Then("^display 'Please fill the valid Address'$")
	public void display_Please_fill_the_valid_Address() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid addressLine$")
	public void user_enters_invalid_addressLine() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("d");
	}

	@Then("^display 'Please fill the valid AddressLine'$")
	public void display_Please_fill_the_valid_AddressLine() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	/*
	 * @Then("^display 'Please fill the valid Contact'$") public void
	 * display_Please_fill_the_valid_Contact() throws Throwable {
	 * personal.clickLogin(); Thread.sleep(2000);
	 * driver.switchTo().alert().accept(); Thread.sleep(2000); }
	 */

	@When("^user enters invalid city$")
	public void user_enters_invalid_city() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("Mumbai");
		personal.selectCity(0);
		
	}

	@Then("^display 'Please select City'$")
	public void display_Please_select_City() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid state index$")
	public void user_enters_invalid_state_index() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("Mumbai");
		personal.selectCity(2);
		personal.selectState(0);
	}

	@Then("^display 'Please select state'$")
	public void display_Please_select_state() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^User click on Next$")
	public void user_click_on_Next() throws Throwable {
		personal.setFirstname("Varsha");
		personal.setLastName("Pandita");
		personal.setEmail("varsha@gmail.com");
		personal.setContact("7758038348");
		personal.setAddress1("Airoli");
		personal.setAddress2("Mumbai");
		personal.selectCity(2);
		personal.selectState(1);
	}

	@Then("^Personal Details are validated and accepted successfully$")
	public void personal_Details_are_validated_and_accepted_successfully() throws Throwable {
		personal.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	/*
	 * @After public void destroy() { driver.quit(); }
	 */

}
