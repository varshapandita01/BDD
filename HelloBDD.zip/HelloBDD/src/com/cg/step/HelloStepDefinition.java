package com.cg.step;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HelloStepDefinition {

	@Before(order=1)
	public void init() {
		System.out.println("Scenario test begin");
	}

	@Before(order=0)
	public void init1() {
		System.out.println("Scenario test begin1");
	}
	
	@After(order=1)
	public void destroy() {
		System.out.println("Scenario test ends");
	}
	
	@After(order=0)
	public void destroy1() {
		System.out.println("Scenario test ends1");
	}

	@Given("^Attended training$")
	public void attendedTraining() throws Throwable {
		System.out.println("1-Attended Training");

	}

	@When("^Clear L(\\d+)$")
	public void clearL1(int arg1) throws Throwable {
		System.out.println("2.Cleared L1");

	}

	@Then("^Become employee$")
	public void becomeEmployee() throws Throwable {
		System.out.println("3.I am a employee");
	}

	@Given("^Hello given step$")
	public void helloGivenStep() throws Throwable {
		System.out.println("Saying Hello to given Step");
	}

	@When("^Hello when step$")
	public void helloWhenStep() throws Throwable {
		System.out.println("Saying Hello to when Step");
	}

	@Then("^Bye then step$")
	public void byeThenStep() throws Throwable {
		System.out.println("Saying Hello to then Step");
	}

	@Given("^Bye given step$")
	public void byeGivenStep() throws Throwable {
		System.out.println("Saying Hello to given Step");
	}

	@When("^Bye when step$")
	public void byeWhenStep() throws Throwable {
		System.out.println("Saying Hello to when Step");
	}

	@Then("^Hello then step$")
	public void helloThenStep() throws Throwable {
		System.out.println("Saying Hello to then Step");
	}

}
