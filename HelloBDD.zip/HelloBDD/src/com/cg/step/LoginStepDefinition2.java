package com.cg.step;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition2 {

	private WebDriver driver;
	private Login login;

	@Before
	public void init() throws InterruptedException {
		// Instatntiate driver
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {
		String url = "file:///C:\\Users\\varpandi\\workspaceBDD\\HelloBDD\\html\\login.html";
		driver.get(url);
		login = new Login();
		PageFactory.initElements(driver, login);

	}

	@When("^User checks user$")
	public void user_checks_user() throws Throwable {
		login.selectUser(1);

	}

	@Then("^Validate user$")
	public void validate_user() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters username details$")
	public void user_enters_username_details() throws Throwable {
		login.selectUser(0);
		login.setUsername("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		login.clickLogin();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enters password details$")
	public void user_enters_password_details() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("123");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user select valid role$")
	public void user_select_valid_role() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.clickRole(0);
	}

	@Then("^validate role$")
	public void validate_role() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user selects remember check$")
	public void user_selects_remember_check() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.clickRole(1);
	}

	@Then("^validate checkbox$")
	public void validate_checkbox() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User click on submit form$")
	public void user_click_on_submit_form() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.clickRole(1);
		login.selectRemember();
	}

	@Then("^Show successfully submitted$")
	public void show_successully_submitted() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@After
	public void destroy() {
		driver.quit();
	}

}
